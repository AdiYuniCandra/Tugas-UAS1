<?php 
		
		$server= "127.0.0.1";
		$user= "root";
		$pw="";
		$db="adi";

		$koneksi= mysqli_connect($server,$user,$pw,$db)or die("koneksi gagal");

?>